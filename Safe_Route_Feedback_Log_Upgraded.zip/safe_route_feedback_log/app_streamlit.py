"""Native-component Streamlit interface sharing the src backend."""
import streamlit as st
from pathlib import Path
from src.storage import Storage
from src.models import Feedback
from src.business_logic import add_record,search_records,summary,warnings,update_status
from src.validators import CATEGORIES
from src.importer import import_csv
from src.exporters import export_csv,export_markdown
st.set_page_config(page_title="Safe Route Feedback Log",page_icon="🛡️",layout="wide")
st.title("🛡️ Safe Route Feedback Log")
st.caption("Local safety observations • shared backend • no network required")
store=Storage(Path("data")); records=store.read_all()
if not records:
    try:
        from seed import seed_if_empty
        seed_if_empty(store); records=store.read_all()
    except Exception: pass
page=st.sidebar.radio("Navigate",["Dashboard","Add Feedback","Search Records","Manage Status","Import CSV","Export Reports"])
if page=="Dashboard":
    s=summary(records); cols=st.columns(6)
    for c,label,val in zip(cols,["Total","Open","In Progress","Resolved","Overdue","Critical"],[s['total'],s['open'],s['in_progress'],s['resolved'],s['overdue'],s['critical']]): c.metric(label,val)
    st.metric("Resolution rate",f"{s['resolution_rate']}%")
    st.subheader("Category totals"); st.bar_chart(s["category_counts"] or {"No data":0})
    st.subheader("Severity totals"); st.bar_chart(s["severity_counts"] or {"No data":0})
    for warning in warnings(records): st.warning(warning)
    st.dataframe([r.to_dict() for r in records],use_container_width=True)
elif page=="Add Feedback":
    with st.form("add_record"):
        date=st.date_input("Observation date"); route=st.text_input("Route"); location=st.text_input("Location"); category=st.selectbox("Category",CATEGORIES); severity=st.selectbox("Severity",["Low","Medium","High","Critical"]); description=st.text_area("Description"); reporter=st.text_input("Reporter (optional)"); due=st.date_input("Follow-up due date",value=None)
        submitted=st.form_submit_button("Save feedback")
    if submitted:
        data={"date":date.isoformat(),"route":route,"location":location,"category":category,"severity":severity,"description":description,"reporter":reporter or "Anonymous","due_date":due.isoformat() if due else "","status":"Open"}
        try: rec=add_record(records,data); store.save(records); store.audit(f"Added feedback {rec.id}"); st.success(f"Saved record {rec.id}")
        except ValueError as e: st.error(str(e))
elif page=="Search Records":
    keyword=st.text_input("Keyword"); category=st.selectbox("Category",[""]+list(CATEGORIES)); status=st.selectbox("Status",["","Open","In Progress","Resolved"]); severity=st.selectbox("Severity",["","Low","Medium","High","Critical"])
    found=search_records(records,keyword,category,status,severity); st.write(f"Found {len(found)} record(s)"); st.dataframe([r.to_dict() for r in found],use_container_width=True)
elif page=="Manage Status":
    st.subheader("Update feedback status")
    if not records:
        st.info("No feedback records available yet.")
    else:
        by_id={r.id:r for r in records}
        selected=st.selectbox("Feedback record",list(by_id),format_func=lambda rid:f"{rid} — {by_id[rid].route} ({by_id[rid].status})")
        record=by_id[selected]
        next_status=st.selectbox("New status",["Open","In Progress","Resolved"],index=["Open","In Progress","Resolved"].index(record.status))
        if st.button("Save status"):
            try:
                update_status(records,selected,next_status)
                store.save(records)
                store.audit(f"Updated status for {selected}: {next_status}")
                st.success(f"{selected} updated to {next_status}.")
                st.rerun()
            except ValueError as e:
                st.error(str(e))
    st.dataframe([r.to_dict() for r in records],use_container_width=True)
elif page=="Import CSV":
    upload=st.file_uploader("Upload a CSV with feedback fields",type=["csv"])
    if upload and st.button("Import CSV"):
        tmp=Path("data/upload.csv"); tmp.write_bytes(upload.getvalue()); result=import_csv(tmp,records); store.save(records); store.audit(f"CSV import accepted={len(result['added'])}, rejected={len(result['errors'])}"); st.success(f"Accepted: {len(result['added'])}; rejected: {len(result['errors'])}"); st.dataframe(result["errors"])
elif page=="Export Reports":
    export_csv(records,"exports/report.csv"); export_markdown(records,"exports/report.md")
    st.download_button("Download CSV",Path("exports/report.csv").read_bytes(),file_name="safe_route_report.csv",mime="text/csv")
    st.download_button("Download Markdown",Path("exports/report.md").read_bytes(),file_name="safe_route_report.md",mime="text/markdown")
    audit=store.audit_path.read_text(encoding="utf-8") if store.audit_path.exists() else ""
    st.download_button("Download audit log",audit,file_name="audit_log.txt",mime="text/plain")
