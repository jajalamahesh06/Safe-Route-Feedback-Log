"""Terminal entry point."""
from pathlib import Path
from src.storage import Storage
from src.ui import run
from seed import seed_if_empty
if __name__=="__main__":
    storage=Storage(Path("data")); seed_if_empty(storage); run(storage)
