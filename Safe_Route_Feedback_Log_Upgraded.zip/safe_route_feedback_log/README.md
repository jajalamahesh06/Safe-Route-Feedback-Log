# Safe Route Feedback Log

A Python application for recording, reviewing and reporting route-safety observations. The command-line and Streamlit interfaces use the same backend and JSON/CSV/SQLite data store.

## Features
- Add validated feedback with route, location, category, severity, reporter and follow-up date.
- Search by keyword and combine category, status and severity filters.
- Track Open, In Progress and Resolved work; the Streamlit **Manage Status** page updates a record and records the change in the audit log.
- Dashboard metrics, category/severity charts, critical-item and overdue warnings.
- CSV import with row-level error reporting; CSV and Markdown report exports.
- Atomic file writes, corrupt-JSON recovery, audit trail and SQLite indexes.

## Run locally
Python 3.10+ recommended. From this folder:

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
streamlit run app_streamlit.py
```

For the terminal menu, run `python main.py`. Seed examples are created only when the data store is empty. To use your own records, keep `data/feedback.json` and `data/feedback.csv` backed up before replacing them.

## Tests
Run from this folder:

```bash
python -m unittest discover -s tests -v
```

## Data and exports
The application stores local data under `data/` and generated reports under `exports/`. Do not publish real reporter names or sensitive incident details in a public repository. The included sample data is for demonstration.

## Limitations
This is a local educational project, not an emergency reporting service. It does not dispatch responders, verify reports, or provide live route conditions. The SQLite file is a searchable mirror; JSON is the primary record source.
