"""Core unit tests."""
import tempfile,json,unittest
from pathlib import Path
from src.validators import validate_feedback,valid_date
from src.models import Feedback
from src.business_logic import add_record,summary,search_records,update_status
from src.storage import Storage
from seed import seed_if_empty
BASE={"date":"2026-01-01","route":"Route A","location":"Gate","category":"Lighting","severity":"High","description":"Broken lights reported","reporter":"Test","status":"Open","due_date":""}
class CoreTests(unittest.TestCase):
 def test_valid(self): self.assertTrue(validate_feedback(BASE)[0])
 def test_blank_rejected(self): d=dict(BASE); d["route"]=""; self.assertFalse(validate_feedback(d)[0])
 def test_date_boundary(self): self.assertTrue(valid_date("2024-02-29")); self.assertFalse(valid_date("2023-02-29"))
 def test_add_summary_search(self):
  r=[]; add_record(r,BASE); self.assertEqual(summary(r)["total"],1); self.assertEqual(len(search_records(r,"broken")),1)
 def test_corrupt_recovery(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/"feedback.json"; p.write_text("{bad",encoding="utf-8"); st=Storage(d); self.assertEqual(st.read_all(),[]); self.assertTrue(list(Path(d).glob("*.bak")))
 def test_seed_and_indexes(self):
  with tempfile.TemporaryDirectory() as d:
   st=Storage(d); seed_if_empty(st); self.assertEqual(len(st.read_all()),40); self.assertTrue(st.indexed_search("Gate"))

 def test_status_update_and_unknown_id(self):
  records=[]; rec=add_record(records,BASE)
  self.assertEqual(update_status(records,rec.id,"Resolved").status,"Resolved")
  with self.assertRaises(ValueError): update_status(records,"missing","Resolved")
  with self.assertRaises(ValueError): update_status(records,rec.id,"Unknown")
 def test_due_date_validation(self):
  d=dict(BASE); d["due_date"]="2026-02-30"
  self.assertFalse(validate_feedback(d)[0])
 def test_search_filters_combine(self):
  records=[]; add_record(records,BASE)
  self.assertEqual(len(search_records(records,category="Lighting",severity="High")),1)
  self.assertEqual(len(search_records(records,category="Traffic")),0)

if __name__=="__main__": unittest.main()
