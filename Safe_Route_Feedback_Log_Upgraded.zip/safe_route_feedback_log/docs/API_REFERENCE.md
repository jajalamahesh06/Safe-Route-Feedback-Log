# Safe Route Feedback Log — API Reference

## Architecture
- `src/models.py`: `Feedback`, `Severity`, and `Status` domain definitions.
- `src/validators.py`: dates, field schema, and resilient interactive prompts.
- `src/storage.py`: atomic JSON/CSV persistence, locking, SQLite mirror and audit.
- `src/business_logic.py`: add, filter, summary and warning logic.
- `src/importer.py`: CSV row validation and rejection details.
- `src/exporters.py`: CSV and Markdown reports.
- `src/ui.py`: paginated ANSI terminal interface.
- `app_streamlit.py`: native Streamlit frontend.

## Feedback schema
`id`, `date`, `route`, `location`, `category`, `severity`, `description`, `reporter`, `status`, `due_date`, `created_at`.

Dates are ISO `YYYY-MM-DD`; severity is Low/Medium/High/Critical; categories are Lighting, Road Condition, Traffic, Visibility, Crowd, Other; status is Open/In Progress/Resolved.

## Functions
- `validate_feedback(data) -> (bool, message)` validates required fields, dates and enums.
- `add_record(records, data) -> Feedback` validates and appends a record.
- `search_records(records, keyword, category, status, severity)` filters in-memory records.
- `summary(records)` returns totals, counts, overdue/critical metrics and resolution rate.
- `warnings(records)` returns critical and overdue warnings.
- `Storage.read_all()`, `Storage.save(records)`, `Storage.audit(message)`, `Storage.indexed_search(term)` persistence and search APIs.
- `import_csv(path, records)` returns added records and row errors.
- `export_csv(records,path)` and `export_markdown(records,path)` write reports.

## Files
Storage lives in `data/`; exports in `exports/`; the SQLite database is `data/feedback.sqlite3`; the audit trail is `data/audit_log.txt`.
