"""Seed 40 representative records for demos and testing."""
from datetime import date,timedelta
from src.models import Feedback
from src.storage import Storage
from src.business_logic import add_record

def seed_if_empty(storage:Storage):
    records=storage.read_all()
    if records: return
    today=date.today()
    routes=["North Gate Walk","Library Loop","Hostel Road","Bus Stop Path","Sports Complex Route","Main Avenue","East Parking Walk","Cafeteria Lane"]
    locs=["Gate A","Near library","Hostel block 2","Bus shelter","Sports entrance","Crossing 3","Parking lot","Cafeteria"]
    cats=["Lighting","Road Condition","Traffic","Visibility","Crowd","Other"]
    sev=["Low","Medium","High","Critical"]
    statuses=["Open","In Progress","Resolved"]
    for i in range(40):
        d=today-timedelta(days=(i%28)); due=today-timedelta(days=2) if i%9==0 else today+timedelta(days=5)
        data={"date":d.isoformat(),"route":routes[i%len(routes)],"location":locs[i%len(locs)],"category":cats[i%len(cats)],"severity":sev[i%4],"description":f"Sample safety observation #{i+1}: review conditions and follow-up action at this location.","reporter":"Demo reporter" if i%5 else "Anonymous","status":statuses[i%3],"due_date":due.isoformat() if i%3!=2 else ""}
        rec=add_record(records,data); rec.id=f"SR-SEED-{i+1:03d}"
    storage.save(records); storage.audit("Seeded 40 demo feedback records")
