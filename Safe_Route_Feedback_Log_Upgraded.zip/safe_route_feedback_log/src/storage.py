"""Thread-safe persistence, recovery, atomic writes, locking and SQLite mirror."""
import csv, json, os, sqlite3, tempfile, threading, time
from pathlib import Path
from contextlib import contextmanager
from src.models import Feedback

class Storage:
    def __init__(self, data_dir: Path|str="data"):
        self.data_dir=Path(data_dir); self.data_dir.mkdir(parents=True,exist_ok=True)
        self.json_path=self.data_dir/"feedback.json"; self.csv_path=self.data_dir/"feedback.csv"
        self.db_path=self.data_dir/"feedback.sqlite3"; self.audit_path=self.data_dir/"audit_log.txt"
        self.lock=threading.RLock(); self.lock_path=self.data_dir/".lock"
        self._init_db(); self._recover_json()
        if not self.csv_path.exists(): self.write_csv(self.read_all())
        self.sync_db(self.read_all())
    @contextmanager
    def file_lock(self):
        with self.lock:
            f=open(self.lock_path,"a+b")
            try:
                try:
                    import msvcrt
                    msvcrt.locking(f.fileno(),msvcrt.LK_LOCK,1)
                except ImportError:
                    import fcntl
                    fcntl.flock(f.fileno(),fcntl.LOCK_EX)
                yield
            finally:
                try:
                    try:
                        import msvcrt
                        f.seek(0); msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
                    except ImportError:
                        import fcntl
                        fcntl.flock(f.fileno(),fcntl.LOCK_UN)
                finally: f.close()
    def _init_db(self):
        with sqlite3.connect(self.db_path) as con:
            con.execute("CREATE TABLE IF NOT EXISTS feedback (id TEXT PRIMARY KEY,date TEXT,route TEXT,location TEXT,category TEXT,severity TEXT,description TEXT,reporter TEXT,status TEXT,due_date TEXT,created_at TEXT)")
            for col in ("date","route","category","severity","status","due_date"):
                con.execute(f"CREATE INDEX IF NOT EXISTS idx_{col} ON feedback({col})")
    def _atomic_write(self,path:Path,text:str):
        path.parent.mkdir(parents=True,exist_ok=True)
        fd,tmp=tempfile.mkstemp(prefix=path.name+".",suffix=".tmp",dir=path.parent)
        try:
            with os.fdopen(fd,"w",encoding="utf-8",newline="") as f: f.write(text); f.flush(); os.fsync(f.fileno())
            os.replace(tmp,path)
        finally:
            if os.path.exists(tmp): os.remove(tmp)
    def _recover_json(self):
        if not self.json_path.exists(): self.write_json([]); return
        try:
            with self.json_path.open(encoding="utf-8") as f: obj=json.load(f)
            if not isinstance(obj,list): raise json.JSONDecodeError("Expected list", "", 0)
        except (FileNotFoundError,json.JSONDecodeError,UnicodeDecodeError):
            if self.json_path.exists():
                backup=self.json_path.with_suffix(f".{time.strftime('%Y%m%d_%H%M%S')}.bak")
                os.replace(self.json_path,backup); self.audit(f"Corrupt JSON archived to {backup.name}")
            self.write_json([])
    def read_all(self)->list[Feedback]:
        with self.file_lock():
            try:
                with self.json_path.open(encoding="utf-8") as f: raw=json.load(f)
                return [Feedback.from_dict(x) for x in raw if isinstance(x,dict)]
            except (FileNotFoundError,json.JSONDecodeError,UnicodeDecodeError): return []
    def write_json(self,records:list[Feedback]):
        with self.file_lock(): self._atomic_write(self.json_path,json.dumps([r.to_dict() for r in records],indent=2,ensure_ascii=False))
    def write_csv(self,records:list[Feedback]):
        fields=list(Feedback.__dataclass_fields__)
        fd,tmp=tempfile.mkstemp(prefix="feedback.",suffix=".tmp",dir=self.data_dir)
        try:
            with os.fdopen(fd,"w",encoding="utf-8",newline="") as f:
                w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows([r.to_dict() for r in records]); f.flush(); os.fsync(f.fileno())
            os.replace(tmp,self.csv_path)
        finally:
            if os.path.exists(tmp): os.remove(tmp)
    def save(self,records:list[Feedback]):
        self.write_json(records); self.write_csv(records); self.sync_db(records)
    def sync_db(self,records:list[Feedback]):
        with sqlite3.connect(self.db_path) as con:
            con.execute("DELETE FROM feedback")
            con.executemany("INSERT OR REPLACE INTO feedback VALUES (?,?,?,?,?,?,?,?,?,?,?)",[tuple(r.to_dict().values()) for r in records])
    def audit(self,message:str):
        with self.file_lock(), self.audit_path.open("a",encoding="utf-8") as f: f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}\n")
    def indexed_search(self,term:str):
        with sqlite3.connect(self.db_path) as con:
            return con.execute("SELECT id,date,route,location,category,severity,status FROM feedback WHERE route LIKE ? OR category LIKE ? OR severity LIKE ? OR location LIKE ? ORDER BY date DESC",tuple([f"%{term}%"]*4)).fetchall()
