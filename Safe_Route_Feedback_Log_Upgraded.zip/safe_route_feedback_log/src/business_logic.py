"""Domain operations and summary analytics."""
from datetime import date
from collections import Counter
from src.models import Feedback
from src.validators import validate_feedback

def add_record(records:list[Feedback], data:dict)->Feedback:
    ok,msg=validate_feedback(data)
    if not ok: raise ValueError(msg)
    from uuid import uuid4
    from datetime import datetime
    data=dict(data); data.setdefault("id",f"SR-{uuid4().hex[:8].upper()}"); data.setdefault("created_at",datetime.now().isoformat(timespec="seconds")); data.setdefault("reporter","Anonymous"); data.setdefault("status","Open"); data.setdefault("due_date","")
    rec=Feedback.from_dict(data); records.append(rec); return rec

def search_records(records:list[Feedback], keyword:str="", category:str="", status:str="", severity:str=""):
    key=keyword.lower()
    return [r for r in records if (not key or key in (r.route+r.location+r.description+r.reporter).lower()) and (not category or r.category==category) and (not status or r.status==status) and (not severity or r.severity==severity)]

def summary(records:list[Feedback])->dict:
    today=date.today().isoformat(); open_items=[r for r in records if r.status!="Resolved"]
    overdue=[r for r in open_items if r.due_date and r.due_date<today]
    sev=Counter(r.severity for r in records); cats=Counter(r.category for r in records); statuses=Counter(r.status for r in records)
    return {"total":len(records),"open":statuses.get("Open",0),"in_progress":statuses.get("In Progress",0),"resolved":statuses.get("Resolved",0),"overdue":len(overdue),"critical":sev.get("Critical",0),"severity_counts":dict(sev),"category_counts":dict(cats),"status_counts":dict(statuses),"resolution_rate":round(statuses.get("Resolved",0)/len(records)*100,1) if records else 0,"avg_severity_score":round(sum({"Low":1,"Medium":2,"High":3,"Critical":4}.get(r.severity,0) for r in records)/len(records),2) if records else 0}

def warnings(records:list[Feedback]):
    today=date.today().isoformat()
    return [f"{r.id}: {r.severity} concern at {r.location}" for r in records if r.severity=="Critical" and r.status!="Resolved"]+[f"{r.id}: overdue follow-up (due {r.due_date})" for r in records if r.due_date and r.due_date<today and r.status!="Resolved"]



def update_status(records: list[Feedback], record_id: str, status: str) -> Feedback:
    """Update a record's workflow status; reject unknown IDs or status values."""
    from src.models import Status
    allowed = {item.value for item in Status}
    if status not in allowed:
        raise ValueError(f"Status must be one of: {', '.join(sorted(allowed))}.")
    for record in records:
        if record.id == record_id:
            record.status = status
            return record
    raise ValueError(f"Feedback record {record_id!r} was not found.")
