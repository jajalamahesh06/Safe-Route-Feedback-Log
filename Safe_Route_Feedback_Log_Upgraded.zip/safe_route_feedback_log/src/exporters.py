"""Export summary and records to CSV and Markdown."""
import csv
from pathlib import Path
from src.models import Feedback
from src.business_logic import summary

def export_csv(records:list[Feedback],path:Path|str):
    fields=list(Feedback.__dataclass_fields__); p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+".tmp")
    with tmp.open("w",encoding="utf-8",newline="") as f: w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows([r.to_dict() for r in records])
    tmp.replace(p)

def export_markdown(records:list[Feedback],path:Path|str):
    s=summary(records); p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    lines=["# Safe Route Feedback Log Report","",f"- Total records: **{s['total']}**",f"- Open: **{s['open']}**",f"- In progress: **{s['in_progress']}**",f"- Resolved: **{s['resolved']}**",f"- Overdue: **{s['overdue']}**",f"- Critical: **{s['critical']}**",f"- Resolution rate: **{s['resolution_rate']}%**","","## Records","","| ID | Date | Route | Location | Category | Severity | Status |","|---|---|---|---|---|---|---|"]
    lines += [f"| {r.id} | {r.date} | {r.route} | {r.location} | {r.category} | {r.severity} | {r.status} |" for r in records]
    p.write_text("\n".join(lines),encoding="utf-8")
