"""Defensive input and schema validation."""
import re
from datetime import datetime
from typing import Callable
from src.models import Feedback, Severity, Status

ID_RE = re.compile(r"^[A-Za-z0-9_-]{2,32}$")
TEXT_RE = re.compile(r"^[^<>]{1,500}$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
CATEGORIES = ("Lighting", "Road Condition", "Traffic", "Visibility", "Crowd", "Other")

def valid_date(value: str, optional: bool=False) -> bool:
    if optional and not value: return True
    if not DATE_RE.fullmatch(value): return False
    try: datetime.strptime(value, "%Y-%m-%d"); return True
    except ValueError: return False

def validate_feedback(data: dict) -> tuple[bool, str]:
    required = ("date", "route", "location", "category", "severity", "description")
    for field in required:
        if not str(data.get(field, "")).strip(): return False, f"{field} cannot be blank."
    if not valid_date(str(data.get("date", ""))): return False, "Date must be YYYY-MM-DD and valid."
    if not valid_date(str(data.get("due_date", "")), optional=True): return False, "Due date must be YYYY-MM-DD or blank."
    if str(data["category"]) not in CATEGORIES: return False, "Unknown category."
    if str(data["severity"]) not in [x.value for x in Severity]: return False, "Unknown severity."
    if str(data.get("status", Status.OPEN.value)) not in [x.value for x in Status]: return False, "Unknown status."
    for field in ("route", "location", "description", "reporter"):
        val=str(data.get(field, ""))
        if field in ("route", "location") and len(val.strip())>120: return False, f"{field} is too long."
        if field == "description" and (not TEXT_RE.fullmatch(val) or len(val.strip())<3): return False, "Description must be 3-500 safe characters."
    return True, "Valid."

def prompt_text(prompt: str, *, required=True, max_length=120) -> str:
    while True:
        value=input(prompt).strip()
        if required and not value: print("Value cannot be blank."); continue
        if len(value)>max_length: print(f"Maximum length is {max_length}."); continue
        if any(ch in value for ch in "<>" ): print("Angle brackets are not allowed."); continue
        return value

def prompt_choice(prompt: str, choices: list[str]) -> str:
    while True:
        value=input(prompt).strip()
        if value in choices: return value
        print("Choose one of: " + ", ".join(choices))

def prompt_date(prompt: str, optional=False) -> str:
    while True:
        value=input(prompt).strip()
        if valid_date(value,optional): return value
        print("Enter a valid YYYY-MM-DD date." if not optional else "Enter YYYY-MM-DD or leave blank.")

def prompt_int(prompt: str, low: int, high: int) -> int:
    while True:
        try: value=int(input(prompt).strip())
        except (ValueError, TypeError): print("Please enter a number."); continue
        if low<=value<=high: return value
        print(f"Enter a value from {low} to {high}.")
