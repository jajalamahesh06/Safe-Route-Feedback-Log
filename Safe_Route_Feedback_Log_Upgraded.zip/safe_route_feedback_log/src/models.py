"""Typed domain models for Safe Route Feedback Log."""
from dataclasses import dataclass, asdict
from enum import Enum
from typing import Any

class Severity(str, Enum):
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    CRITICAL = "Critical"

class Status(str, Enum):
    OPEN = "Open"
    IN_PROGRESS = "In Progress"
    RESOLVED = "Resolved"

@dataclass
class Feedback:
    id: str
    date: str
    route: str
    location: str
    category: str
    severity: str
    description: str
    reporter: str = "Anonymous"
    status: str = "Open"
    due_date: str = ""
    created_at: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Feedback":
        fields = cls.__dataclass_fields__
        return cls(**{k: data.get(k, fields[k].default) for k in fields})
