"""Bulk CSV import with per-row validation and error capture."""
import csv
from pathlib import Path
from src.validators import validate_feedback
from src.models import Feedback
from src.business_logic import add_record

def import_csv(path:Path|str,records:list[Feedback])->dict:
    added=[]; errors=[]
    with Path(path).open(encoding="utf-8-sig",newline="") as f:
        for line,row in enumerate(csv.DictReader(f),start=2):
            ok,msg=validate_feedback(row)
            if not ok: errors.append({"row":line,"error":msg}); continue
            try: added.append(add_record(records,row))
            except Exception as exc: errors.append({"row":line,"error":str(exc)})
    return {"added":added,"errors":errors}
