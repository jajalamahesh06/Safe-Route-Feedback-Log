"""ANSI terminal menu and paginated record display."""
import os
from datetime import datetime
from src.models import Feedback
from src.validators import prompt_text,prompt_choice,prompt_date,CATEGORIES
from src.business_logic import add_record,search_records,summary,warnings
from src.importer import import_csv
from src.exporters import export_csv,export_markdown

RESET="\033[0m"; CYAN="\033[36m"; GREEN="\033[32m"; YELLOW="\033[33m"; RED="\033[31m"; BOLD="\033[1m"
def clear(): os.system("cls" if os.name=="nt" else "clear")
def table(records,page_size=10):
    cols=[("ID",12),("Date",10),("Route",18),("Location",22),("Category",16),("Severity",10),("Status",14)]
    def row(vals): return " | ".join(str(v)[:w].ljust(w) for v,(_,w) in zip(vals,cols))
    print(row([c[0] for c in cols])); print("-"*sum(w+3 for _,w in cols))
    for start in range(0,len(records),page_size):
        for r in records[start:start+page_size]: print(row([r.id,r.date,r.route,r.location,r.category,r.severity,r.status]))
        if start+page_size<len(records): input("-- page break: press Enter --")
def run(storage):
    records=storage.read_all()
    while True:
        clear(); print(f"{CYAN}{BOLD} SAFE ROUTE FEEDBACK LOG {RESET}"); print("="*32)
        print("1. Add feedback\n2. View all records\n3. Search / filter\n4. Executive summary & warnings\n5. Bulk CSV import\n6. Export reports\n7. Exit")
        choice=input("\nChoose (1-7): ").strip()
        try:
            if choice=="1":
                data={"date":prompt_date("Observation date YYYY-MM-DD: "),"route":prompt_text("Route / pathway: "),"location":prompt_text("Location / landmark: "),"category":prompt_choice("Category "+str(CATEGORIES)+": ",list(CATEGORIES)),"severity":prompt_choice("Severity (Low/Medium/High/Critical): ",["Low","Medium","High","Critical"]),"description":prompt_text("Description: ",max_length=500),"reporter":prompt_text("Reporter (blank = Anonymous): ",required=False),"status":"Open","due_date":prompt_date("Follow-up due date (blank allowed): ",optional=True)}
                r=add_record(records,data); storage.save(records); storage.audit(f"Added feedback {r.id}"); print(GREEN+f"Saved {r.id}"+RESET); input("Enter to continue")
            elif choice=="2": table(records); input("Enter to continue")
            elif choice=="3":
                kw=input("Keyword (blank any): ").strip(); cat=input("Category (blank any): ").strip(); status=input("Status (blank any): ").strip(); sev=input("Severity (blank any): ").strip(); results=search_records(records,kw,cat,status,sev); table(results); input("Enter to continue")
            elif choice=="4":
                s=summary(records); print(f"Total: {s['total']} | Open: {s['open']} | In progress: {s['in_progress']} | Resolved: {s['resolved']} | Overdue: {s['overdue']} | Critical: {s['critical']} | Resolution: {s['resolution_rate']}% | Avg severity score: {s['avg_severity_score']}")
                print("\nSeverity:",s["severity_counts"]); print("Categories:",s["category_counts"]); print("\nWarnings:"); [print(RED+"! "+w+RESET) for w in warnings(records)] or print("No warnings."); input("Enter to continue")
            elif choice=="5":
                path=prompt_text("CSV file path: "); result=import_csv(path,records); storage.save(records); storage.audit(f"Bulk import: {len(result['added'])} accepted, {len(result['errors'])} rejected")
                print(f"Imported {len(result['added'])}; rejected {len(result['errors'])}"); [print(f"Row {e['row']}: {e['error']}") for e in result['errors']]; input("Enter to continue")
            elif choice=="6":
                export_csv(records,"exports/report.csv"); export_markdown(records,"exports/report.md"); print("Reports saved in exports/"); input("Enter to continue")
            elif choice=="7": storage.audit("Application exited"); break
            else: print("Invalid menu choice."); input("Enter to continue")
        except (ValueError,OSError) as exc: print(RED+str(exc)+RESET); input("Enter to continue")
